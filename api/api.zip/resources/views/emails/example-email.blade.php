<!DOCTYPE html>
<html>
<head>
    <title>Example Email</title>
</head>
<body>
    <p>{{ $data['paragraph'] }}</p>
    <a href="{{ $data['link'] }}">Click here for instructions</a>
</body>
</html>
